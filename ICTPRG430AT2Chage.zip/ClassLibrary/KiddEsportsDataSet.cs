﻿namespace ClassLibrary
{
}

namespace ClassLibrary
{


    public partial class KiddEsportsDataSet
    {
    }
}

namespace ClassLibrary.KiddEsportsDataSetTableAdapters {
    
    
    public partial class TeamResultsTableAdapter {
    }
}
